package com.playx.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { PlayXApp() }
    }
}

val CHIPS = listOf("Todos", "4+ jugadores", "Fiesta", "Mesa", "Mente", "Rapidez", "Estrategia", "Cartas")

@Composable
fun PlayXApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("playx", Context.MODE_PRIVATE) }
    val favs = remember {
        mutableStateListOf<Int>().apply { addAll((prefs.getStringSet("fav", emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }) }
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openId by rememberSaveable { mutableIntStateOf(-1) }
    var playing by rememberSaveable { mutableStateOf(false) }
    var players by rememberSaveable { mutableIntStateOf(2) }
    BackHandler(openId >= 0) { if (playing) playing = false else openId = -1 }
    GlassBackground {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            val game = CATALOG.firstOrNull { it.id == openId }
            if (game != null && playing) {
                PlayScreen(game, players.coerceIn(game.minP, game.maxP)) { playing = false }
            } else if (game != null) {
                DetailScreen(
                    game, players, { players = it }, favs.contains(game.id),
                    onFav = {
                        if (favs.contains(game.id)) favs.remove(game.id) else favs.add(game.id)
                        prefs.edit().putStringSet("fav", favs.map { it.toString() }.toSet()).apply()
                    },
                    onBack = { openId = -1 }, onPlay = { playing = true }
                )
            } else {
                Box(Modifier.weight(1f)) { Home(tab, favs) { openId = it.id; players = 2.coerceIn(it.minP, it.maxP) } }
                NavBar(tab) { tab = it }
            }
        }
    }
}

@Composable
fun Home(tab: Int, favs: List<Int>, onOpen: (Game) -> Unit) {
    var chip by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    val list = remember(tab, chip, query, favs.size) {
        CATALOG.filter { gm ->
            val okTab = when (tab) {
                1 -> query.isBlank() || gm.name.contains(query, ignoreCase = true) || gm.eng.cat.contains(query, ignoreCase = true)
                2 -> favs.contains(gm.id)
                else -> when (chip) { 0 -> true; 1 -> gm.maxP >= 4; else -> gm.eng.cat == CHIPS[chip] }
            }
            okTab
        }
    }
    val daily = CATALOG[((System.currentTimeMillis() / 86_400_000L) % CATALOG.size).toInt()]
    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row {
                        T("Play", 30, true)
                        T("X", 30, true, Red)
                    }
                    T("${CATALOG.size} juegos", 13, color = Color.White.copy(alpha = 0.6f))
                }
                if (tab == 0) {
                    Glass(Modifier.fillMaxWidth(), onClick = { onOpen(daily) }) {
                        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            GlassIcon(daily.eng.icon, 64.dp)
                            Column(Modifier.weight(1f)) {
                                T("Juego del día", 11, color = Color(0xFFFFB4B4))
                                T(daily.name, 19, true, lines = 2)
                                T(daily.players(), 12, color = Color.White.copy(alpha = 0.65f))
                            }
                            GlassIcon(Ic.PLAY, 48.dp)
                        }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CHIPS.forEachIndexed { i, label ->
                            val on = i == chip
                            val shape = RoundedCornerShape(50)
                            Box(
                                Modifier.clip(shape)
                                    .background(if (on) Red.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.07f))
                                    .border(1.dp, if (on) Color.White.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.18f), shape)
                                    .clickable { chip = i }
                            ) { T(label, 13, on, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)) }
                        }
                    }
                }
                if (tab == 1) {
                    Glass(Modifier.fillMaxWidth(), radius = 50.dp) {
                        Box(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
                            if (query.isEmpty()) T("Buscar juego o categoría", 16, color = Color.White.copy(alpha = 0.5f))
                            BasicTextField(query, { query = it }, textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(Red), singleLine = true, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                if (tab == 2) T("Favoritos", 20, true)
            }
        }
        if (list.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                T(if (tab == 2) "Aún no tienes favoritos. Abre un juego y toca la estrella." else "No hay juegos con ese filtro.", 15, color = Color.White.copy(alpha = 0.7f), align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(24.dp))
            }
        }
        items(list, key = { it.id }) { gm -> GameCard(gm) { onOpen(gm) } }
    }
}

@Composable
fun GameCard(g: Game, onClick: () -> Unit) {
    Glass(Modifier.fillMaxWidth(), onClick = onClick) {
        Column(Modifier.padding(14.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassIcon(g.eng.icon, 52.dp)
            T(g.name, 15, true, lines = 2, modifier = Modifier.heightIn(min = 40.dp))
            T(g.players(), 11, color = Color.White.copy(alpha = 0.62f))
            val shape = RoundedCornerShape(50)
            Box(Modifier.clip(shape).background(Red.copy(alpha = 0.2f)).border(1.dp, Red.copy(alpha = 0.5f), shape)) {
                T(g.eng.cat, 10, color = Color(0xFFFFD9D9), modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
            }
        }
    }
}

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    Glass(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), radius = 36.dp) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
            listOf(Triple("Inicio", Ic.HOME, 0), Triple("Buscar", Ic.SEARCH, 1), Triple("Favoritos", Ic.STAR, 2)).forEach { (label, icon, i) ->
                Column(Modifier.clickable { onTab(i) }.padding(horizontal = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    GlassIcon(icon, 44.dp, Modifier.alpha(if (tab == i) 1f else 0.5f))
                    T(label, 10, tab == i, Color.White.copy(alpha = if (tab == i) 1f else 0.55f))
                }
            }
        }
    }
}

@Composable
fun DetailScreen(g: Game, players: Int, onPlayers: (Int) -> Unit, fav: Boolean, onFav: () -> Unit, onBack: () -> Unit, onPlay: () -> Unit) {
    val n = players.coerceIn(g.minP, g.maxP)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            GlassIcon(Ic.BACK, 46.dp, Modifier.clickable { onBack() })
            GlassIcon(Ic.STAR, 46.dp, Modifier.alpha(if (fav) 1f else 0.45f).clickable { onFav() })
        }
        GlassIcon(g.eng.icon, 110.dp)
        T(g.name, 26, true, align = TextAlign.Center)
        T("${g.eng.cat} · ${g.players()} · ${g.desc}", 13, color = Color.White.copy(alpha = 0.65f), align = TextAlign.Center)
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                T("Cómo se juega", 15, true)
                T(g.eng.rules, 14, color = Color.White.copy(alpha = 0.8f))
            }
        }
        if (g.minP < g.maxP) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Btn("−", primary = false, enabled = n > g.minP) { onPlayers(n - 1) }
                T("$n jugadores", 18, true)
                Btn("+", primary = false, enabled = n < g.maxP) { onPlayers(n + 1) }
            }
        }
        Btn("Jugar", Modifier.fillMaxWidth()) { onPlay() }
    }
}

@Composable
fun PlayScreen(g: Game, n: Int, onBack: () -> Unit) {
    var run by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassIcon(Ic.BACK, 44.dp, Modifier.clickable { onBack() })
            T(g.name, 18, true, lines = 1)
        }
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            key(run) {
                val ctl = Ctl(again = { run++ }, exit = onBack)
                when (g.eng) {
                    Eng.PARTY -> PartyGame(g, n, ctl)
                    Eng.BASTA -> BastaGame(g, n, ctl)
                    Eng.TORRE -> TorreGame(g, n, ctl)
                    Eng.IMPERIO -> ImperioGame(g, n, ctl)
                    Eng.CARRERA -> CarreraGame(g, n, ctl)
                    Eng.MEMORY -> MemoryGame(g, n, ctl)
                    Eng.LINE -> LineGame(g, ctl)
                    Eng.MATH -> MathGame(g, n, ctl)
                    Eng.TRIVIA -> TriviaGame(g, n, ctl)
                    Eng.REACT -> if (g.b == 1) SoloReact(g, ctl) else DuelGame(g, ctl)
                    Eng.HILO -> HiLoGame(g, ctl)
                    Eng.SIMON -> SimonGame(g, ctl)
                    Eng.GUESS -> GuessGame(g, ctl)
                }
            }
        }
    }
}
