package com.playx.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val Red = Color(0xFFFF2D3F)
val RedDeep = Color(0xFF8A0014)
val Ink = Color(0xFF030102)
val PCOL = listOf(Color(0xFFFF2D3F), Color(0xFFFFFFFF), Color(0xFFFFC857), Color(0xFF5BD1FF), Color(0xFFA78BFA), Color(0xFF7CE38B))

fun pn(i: Int) = "Jugador ${i + 1}"
fun sl(n: Int, v: Int) = mutableStateListOf<Int>().apply { repeat(n) { add(v) } }
fun sb(n: Int, v: Boolean) = mutableStateListOf<Boolean>().apply { repeat(n) { add(v) } }

val LocalShimmer = compositionLocalOf<State<Float>> { mutableStateOf(0f) }

@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "bg")
    val p = t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    val sh = t.animateFloat(-1f, 2f, infiniteRepeatable(tween(5200, easing = LinearEasing)), label = "s")
    CompositionLocalProvider(LocalShimmer provides sh) {
        Box(
            Modifier.fillMaxSize().background(Ink).drawBehind {
                val v = p.value
                val c = Offset(size.width * (0.40f + 0.20f * v), size.height * (0.42f + 0.08f * (1f - v)))
                drawRect(Brush.radialGradient(listOf(Red.copy(alpha = 0.50f), RedDeep.copy(alpha = 0.22f), Color.Transparent), center = c, radius = size.width * (0.95f + 0.10f * v)))
                drawRect(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.55f), Color.Transparent, Color.Black.copy(alpha = 0.70f))))
            },
            content = content
        )
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, radius: Dp = 24.dp, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val sh = LocalShimmer.current
    val shape = RoundedCornerShape(radius)
    val base = modifier
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.04f), Red.copy(alpha = 0.12f))))
        .drawWithContent {
            drawContent()
            val x = size.width * sh.value
            drawRect(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.10f), Color.Transparent), start = Offset(x - size.width * 0.3f, 0f), end = Offset(x, size.height * 0.6f)))
        }
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Red.copy(alpha = 0.55f), Color.White.copy(alpha = 0.12f))), shape)
    Column(if (onClick != null) base.clickable(onClick = onClick) else base, content = content)
}

enum class Ic { STACK, PEN, HOME, CARDS, DICE, USERS, GRID, BOLT, PLUS, DOTS, SEARCH, PLAY, BACK, STAR, CROSS, TARGET }

@Composable
fun GlassIcon(kind: Ic, dp: Dp = 52.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(dp)) {
        val r = size.minDimension / 2f
        val c = center
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.60f), Color.White.copy(alpha = 0.10f), Red.copy(alpha = 0.42f), RedDeep.copy(alpha = 0.75f)), center = Offset(c.x * 0.8f, c.y * 0.65f), radius = r * 1.5f))
        drawCircle(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.9f), Red.copy(alpha = 0.6f), Color.White.copy(alpha = 0.2f))), radius = r - r * 0.03f, style = Stroke(width = r * 0.06f))
        drawOval(Color.White.copy(alpha = 0.30f), Offset(c.x - r * 0.55f, r * 0.10f), Size(r * 1.1f, r * 0.45f))
        glyph(kind, r)
    }
}

private fun DrawScope.glyph(k: Ic, r: Float) {
    val w = Color.White
    val s = Stroke(width = r * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val lw = r * 0.12f
    val c = center
    val u = r * 0.42f
    when (k) {
        Ic.STACK -> for (i in -1..1) drawRoundRect(w, Offset(c.x - u, c.y + i * u * 0.75f - u * 0.22f), Size(u * 2f, u * 0.44f), CornerRadius(u * 0.12f), style = s)
        Ic.PEN -> {
            drawLine(w, Offset(c.x - u, c.y + u), Offset(c.x + u, c.y - u), lw, StrokeCap.Round)
            drawLine(w, Offset(c.x - u, c.y + u), Offset(c.x - u * 0.2f, c.y + u), lw, StrokeCap.Round)
        }
        Ic.HOME -> {
            val p = Path()
            p.moveTo(c.x - u, c.y); p.lineTo(c.x, c.y - u); p.lineTo(c.x + u, c.y)
            p.lineTo(c.x + u, c.y + u); p.lineTo(c.x - u, c.y + u); p.close()
            drawPath(p, w, style = s)
        }
        Ic.CARDS -> {
            drawRoundRect(w, Offset(c.x - u, c.y - u), Size(u * 1.4f, u * 1.8f), CornerRadius(u * 0.2f), style = s)
            drawRoundRect(w, Offset(c.x - u * 0.4f, c.y - u * 0.7f), Size(u * 1.4f, u * 1.8f), CornerRadius(u * 0.2f), style = s)
        }
        Ic.DICE -> {
            drawRoundRect(w, Offset(c.x - u, c.y - u), Size(u * 2f, u * 2f), CornerRadius(u * 0.5f), style = s)
            for (o in listOf(-0.45f, 0f, 0.45f)) drawCircle(w, r * 0.07f, Offset(c.x + o * u, c.y + o * u))
        }
        Ic.USERS -> {
            drawCircle(w, u * 0.45f, Offset(c.x, c.y - u * 0.4f), style = s)
            drawArc(w, 200f, 140f, false, Offset(c.x - u, c.y + u * 0.1f), Size(u * 2f, u * 1.6f), style = s)
        }
        Ic.GRID -> for (i in 0..1) for (j in 0..1) drawRoundRect(w, Offset(c.x - u + i * u * 1.1f, c.y - u + j * u * 1.1f), Size(u * 0.9f, u * 0.9f), CornerRadius(u * 0.2f), style = s)
        Ic.BOLT -> {
            val p = Path()
            p.moveTo(c.x + u * 0.2f, c.y - u); p.lineTo(c.x - u * 0.6f, c.y + u * 0.15f); p.lineTo(c.x, c.y + u * 0.15f)
            p.lineTo(c.x - u * 0.2f, c.y + u); p.lineTo(c.x + u * 0.6f, c.y - u * 0.2f); p.lineTo(c.x, c.y - u * 0.2f); p.close()
            drawPath(p, w, style = s)
        }
        Ic.PLUS -> {
            drawLine(w, Offset(c.x - u, c.y), Offset(c.x + u, c.y), lw, StrokeCap.Round)
            drawLine(w, Offset(c.x, c.y - u), Offset(c.x, c.y + u), lw, StrokeCap.Round)
        }
        Ic.DOTS -> for (i in 0..1) for (j in 0..1) drawCircle(w, u * 0.32f, Offset(c.x + (i - 0.5f) * u * 1.3f, c.y + (j - 0.5f) * u * 1.3f), style = s)
        Ic.SEARCH -> {
            drawCircle(w, u * 0.7f, Offset(c.x - u * 0.15f, c.y - u * 0.15f), style = s)
            drawLine(w, Offset(c.x + u * 0.4f, c.y + u * 0.4f), Offset(c.x + u, c.y + u), lw, StrokeCap.Round)
        }
        Ic.PLAY -> {
            val p = Path()
            p.moveTo(c.x - u * 0.5f, c.y - u); p.lineTo(c.x + u * 0.9f, c.y); p.lineTo(c.x - u * 0.5f, c.y + u); p.close()
            drawPath(p, w)
        }
        Ic.BACK -> {
            val p = Path()
            p.moveTo(c.x + u * 0.3f, c.y - u); p.lineTo(c.x - u * 0.5f, c.y); p.lineTo(c.x + u * 0.3f, c.y + u)
            drawPath(p, w, style = s)
        }
        Ic.STAR -> {
            val p = Path()
            for (i in 0 until 10) {
                val rr = if (i % 2 == 0) u * 1.15f else u * 0.5f
                val a = Math.PI * i / 5.0 - Math.PI / 2.0
                val x = c.x + rr * cos(a).toFloat()
                val y = c.y + rr * sin(a).toFloat()
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
            drawPath(p, w, style = s)
        }
        Ic.CROSS -> {
            drawLine(w, Offset(c.x - u, c.y - u), Offset(c.x + u, c.y + u), lw, StrokeCap.Round)
            drawLine(w, Offset(c.x + u, c.y - u), Offset(c.x - u, c.y + u), lw, StrokeCap.Round)
        }
        Ic.TARGET -> {
            drawCircle(w, u * 1.1f, c, style = s)
            drawCircle(w, u * 0.55f, c, style = s)
            drawCircle(w, u * 0.15f, c)
        }
    }
}

@Composable
fun T(text: String, size: Int = 16, bold: Boolean = false, color: Color = Color.White, align: TextAlign = TextAlign.Start, modifier: Modifier = Modifier, lines: Int = Int.MAX_VALUE) {
    BasicText(
        text, modifier,
        style = TextStyle(color = color, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, textAlign = align),
        maxLines = lines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, primary: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fill = if (primary) Brush.verticalGradient(listOf(Color(0xFFFF5A68), Color(0xFFB0001A)))
    else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.05f)))
    Box(
        modifier.heightIn(min = 52.dp).clip(shape).background(fill)
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.7f), Red.copy(alpha = 0.4f))), shape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        T(text, 16, true, Color.White.copy(alpha = if (enabled) 1f else 0.4f), TextAlign.Center, Modifier.padding(horizontal = 20.dp, vertical = 14.dp))
    }
}

class Ctl(val again: () -> Unit, val exit: () -> Unit)

@Composable
fun Result(title: String, lines: List<String>, c: Ctl) {
    Glass(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            T(title, 24, true, align = TextAlign.Center)
            lines.forEach { T(it, 16, color = Color.White.copy(alpha = 0.8f), align = TextAlign.Center) }
            Spacer(Modifier.height(8.dp))
            Btn("Jugar otra vez", Modifier.fillMaxWidth(), onClick = c.again)
            Btn("Salir", Modifier.fillMaxWidth(), primary = false, onClick = c.exit)
        }
    }
}
