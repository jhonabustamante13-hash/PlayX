package com.playx.app

val LETTERS = "ABCDEFGHILMNOPRSTV"
val TCATS = listOf("Geografía", "Ciencia", "Historia", "Deporte y cultura", "Mixto")

val BASTA_SETS: List<Pair<String, List<String>>> = listOf(
    "Clásico" to listOf("Nombre", "Animal", "Color", "Fruta", "País", "Cosa"),
    "Cocina" to listOf("Fruta", "Verdura", "Plato típico", "Bebida", "Postre"),
    "Naturaleza" to listOf("Animal", "Planta", "Río o mar", "Montaña", "Insecto"),
    "Ciudad" to listOf("País", "Ciudad", "Lugar turístico", "Oficio", "Transporte"),
    "Fiesta" to listOf("Canción", "Baile", "Película", "Cantante", "Personaje"),
    "Hogar" to listOf("Mueble", "Electrodoméstico", "Herramienta", "Prenda", "Juguete"),
    "Deportes" to listOf("Deporte", "Equipo", "Deportista", "Accesorio", "Lugar de juego"),
    "Escuela" to listOf("Materia", "Útil escolar", "Profesión", "Libro", "Personaje histórico")
)

val DECKS: List<Pair<String, List<String>>> = listOf(
    "Verdad o reto" to listOf(
        "Verdad: ¿Cuál es tu mayor miedo irracional?", "Reto: Imita a un animal durante 15 segundos.",
        "Verdad: ¿Qué es lo más vergonzoso que te ha pasado en público?", "Reto: Habla con acento extranjero hasta tu próximo turno.",
        "Verdad: ¿Qué canción te da vergüenza que te guste?", "Reto: Baila sin música durante 20 segundos.",
        "Verdad: ¿Cuál fue tu primer trabajo o tarea?", "Reto: Cuenta un chiste e intenta hacer reír a alguien.",
        "Verdad: ¿A quién del grupo le pedirías un consejo?", "Reto: Di el abecedario al revés lo más rápido que puedas."),
    "Yo nunca" to listOf(
        "Yo nunca me he quedado dormido en el cine.", "Yo nunca he mentido para no ir a una fiesta.",
        "Yo nunca he enviado un mensaje a la persona equivocada.", "Yo nunca he llegado tarde a un examen.",
        "Yo nunca he cantado en la ducha a todo volumen.", "Yo nunca he perdido las llaves más de una vez.",
        "Yo nunca he fingido que me gustaba un regalo.", "Yo nunca me he perdido en mi propia ciudad.",
        "Yo nunca he hablado dormido.", "Yo nunca he olvidado el cumpleaños de alguien cercano."),
    "¿Quién es más probable?" to listOf(
        "A la cuenta de tres, señalen: ¿quién se perdería en un centro comercial?", "Señalen: ¿quién ganaría un concurso de baile?",
        "Señalen: ¿quién llegaría tarde a su propia boda?", "Señalen: ¿quién se haría famoso?",
        "Señalen: ¿quién sobreviviría en una isla desierta?", "Señalen: ¿quién olvidaría un cumpleaños?",
        "Señalen: ¿quién adoptaría diez gatos?", "Señalen: ¿quién se dormiría en una película?",
        "Señalen: ¿quién viajaría solo por el mundo?", "Señalen: ¿quién se reiría en un momento serio?"),
    "Charadas" to listOf(
        "Actúa sin hablar: Astronauta", "Actúa sin hablar: Pizza", "Actúa sin hablar: Elefante", "Actúa sin hablar: Dentista",
        "Actúa sin hablar: Surfista", "Actúa sin hablar: Mago", "Actúa sin hablar: Bombero", "Actúa sin hablar: Fantasma",
        "Actúa sin hablar: Cocinero", "Actúa sin hablar: Robot"),
    "Dibuja y adivina" to listOf(
        "Dibuja en papel: Casa", "Dibuja en papel: Bicicleta", "Dibuja en papel: Volcán", "Dibuja en papel: Pirata",
        "Dibuja en papel: Cohete", "Dibuja en papel: Castillo", "Dibuja en papel: Paraguas", "Dibuja en papel: Guitarra",
        "Dibuja en papel: Dinosaurio", "Dibuja en papel: Faro"),
    "Silla caliente" to listOf(
        "Cuéntanos tu mejor recuerdo de la infancia.", "¿Qué superpoder elegirías y por qué?", "¿Cuál es tu comida favorita del mundo?",
        "¿Qué harías con un millón de dólares?", "¿A qué lugar viajarías mañana?", "¿Qué habilidad te gustaría aprender?",
        "Describe tu día perfecto.", "¿Cuál es tu película favorita y por qué?", "¿Qué le dirías a tu yo de hace diez años?", "¿Cuál es tu mayor logro?"),
    "Retos de grupo" to listOf(
        "Todos: canten juntos una canción conocida.", "Todos: hagan 10 saltos a la vez.", "Todos: pasen un objeto sin usar las manos.",
        "Todos: digan 'tres tristes tigres' a la vez sin equivocarse.", "Todos: hagan la mejor pose de foto grupal.",
        "Todos: cuenten hasta 20, uno por persona, sin repetir ni pausar.", "Todos: imiten un animal al mismo tiempo.",
        "Todos: aplaudan al mismo ritmo 10 veces.", "Todos: hagan un brindis creativo.", "Todos: formen una torre humana de rodillas."),
    "Esto o aquello" to listOf(
        "¿Playa o montaña? Defiende tu elección.", "¿Pizza o hamburguesa?", "¿Madrugar o trasnochar?", "¿Verano o invierno?",
        "¿Perros o gatos?", "¿Viajar al pasado o al futuro?", "¿Dulce o salado?", "¿Cine o series?",
        "¿Ser invisible o volar?", "¿Leer mentes o teletransportarte?"),
    "Categorías relámpago" to listOf(
        "Menciona 5 frutas rojas en 10 segundos.", "Menciona 5 países de América en 10 segundos.", "Menciona 5 animales de granja en 10 segundos.",
        "Menciona 5 instrumentos musicales en 10 segundos.", "Menciona 5 deportes de equipo en 10 segundos.",
        "Menciona 5 cosas de una cocina en 10 segundos.", "Menciona 5 profesiones en 10 segundos.",
        "Menciona 5 ciudades de Europa en 10 segundos.", "Menciona 5 colores en 10 segundos.", "Menciona 5 verduras en 10 segundos."),
    "Imitaciones" to listOf(
        "Imita a un profesor muy estricto.", "Imita a un bebé que quiere comer.", "Imita a un locutor de noticias.",
        "Imita a un robot descompuesto.", "Imita a un abuelito contando historias.", "Imita a un gallo al amanecer.",
        "Imita a un presentador de deportes.", "Imita a un villano de película.", "Imita a alguien que ve un fantasma.", "Imita a un cantante en pleno concierto."),
    "Trabalenguas" to listOf(
        "Tres tristes tigres tragaban trigo en un trigal.", "Pablito clavó un clavito.", "El cielo está enladrillado, ¿quién lo desenladrillará?",
        "Pedro Pérez pintor pinta pinturas por poco precio.", "Erre con erre cigarro, erre con erre barril.", "Compré pocas copas, pocas copas compré.",
        "Si Pancha plancha con cuatro planchas, ¿con cuántas planchas plancha Pancha?", "Un tigre, dos tigres, tres tigres.",
        "Paco Peco, chico rico, insultaba como un loco.", "Cuando cuentes cuentos, cuenta cuántos cuentos cuentas."),
    "Dilemas" to listOf(
        "¿Mucho dinero o mucho tiempo libre? Elige y explica.", "¿Hablar todos los idiomas o tocar todos los instrumentos?",
        "¿Vivir sin música o sin películas?", "¿Comer siempre tu comida favorita o probar algo nuevo cada día?",
        "¿Una mascota que habla o un robot que cocina?", "¿Vivir en una casa en un árbol o en un barco?",
        "¿Volver a la escuela sabiendo lo de hoy o tener universidad gratis?", "¿Pausar el tiempo o rebobinarlo 10 segundos?",
        "¿Ser el más inteligente o el más simpático del grupo?", "¿Tener teletransporte o poder volar?")
)

class QA(val cat: Int, val q: String, val o: List<String>)
private fun qa(c: Int, q: String, vararg o: String) = QA(c, q, o.toList())

// La primera opción es siempre la correcta; se mezclan al jugar.
val QS: List<QA> = listOf(
    qa(0, "¿Cuál es la capital de Australia?", "Canberra", "Sídney", "Melbourne", "Perth"),
    qa(0, "¿Cuál es el océano más grande?", "Pacífico", "Atlántico", "Índico", "Ártico"),
    qa(0, "¿Cuál es la montaña más alta sobre el nivel del mar?", "Everest", "K2", "Kilimanjaro", "Mont Blanc"),
    qa(0, "¿Cuántos continentes se reconocen comúnmente?", "7", "5", "6", "8"),
    qa(0, "¿Cuál es la capital de Canadá?", "Ottawa", "Toronto", "Vancouver", "Montreal"),
    qa(0, "¿Qué desierto cálido es el más grande?", "Sahara", "Gobi", "Kalahari", "Atacama"),
    qa(0, "¿Cuál es la capital de Argentina?", "Buenos Aires", "Córdoba", "Rosario", "Montevideo"),
    qa(0, "¿Qué país tiene mayor superficie?", "Rusia", "Canadá", "China", "Estados Unidos"),
    qa(1, "¿Cuál es el planeta más cercano al Sol?", "Mercurio", "Venus", "Marte", "Júpiter"),
    qa(1, "¿Cuál es el símbolo químico del oro?", "Au", "Ag", "Or", "Go"),
    qa(1, "¿Cuántos huesos tiene un adulto?", "206", "150", "300", "180"),
    qa(1, "¿Qué planeta es conocido como el planeta rojo?", "Marte", "Venus", "Saturno", "Neptuno"),
    qa(1, "¿Cuántas cámaras tiene el corazón humano?", "4", "2", "3", "5"),
    qa(1, "¿Cuál es el órgano más grande del cuerpo humano?", "La piel", "El hígado", "El corazón", "El pulmón"),
    qa(1, "¿Qué gas es el más abundante en la atmósfera?", "Nitrógeno", "Oxígeno", "Dióxido de carbono", "Hidrógeno"),
    qa(1, "¿Cuál es la fórmula química del agua?", "H2O", "CO2", "O2", "NaCl"),
    qa(2, "¿En qué año llegó Colón a América?", "1492", "1500", "1453", "1521"),
    qa(2, "¿Quién pintó la Mona Lisa?", "Leonardo da Vinci", "Miguel Ángel", "Rafael", "Van Gogh"),
    qa(2, "¿En qué año cayó el Muro de Berlín?", "1989", "1975", "1991", "1961"),
    qa(2, "¿Qué civilización construyó Machu Picchu?", "Inca", "Maya", "Azteca", "Olmeca"),
    qa(2, "¿Quién fue el primer presidente de Estados Unidos?", "George Washington", "Abraham Lincoln", "Thomas Jefferson", "John Adams"),
    qa(2, "¿En qué año terminó la Segunda Guerra Mundial?", "1945", "1939", "1950", "1918"),
    qa(2, "¿En qué país están las pirámides de Giza?", "Egipto", "México", "Sudán", "Irak"),
    qa(2, "¿En qué año comenzó la Revolución Francesa?", "1789", "1815", "1750", "1848"),
    qa(3, "¿Cuántos jugadores por equipo hay en la cancha en fútbol?", "11", "9", "10", "12"),
    qa(3, "¿Cuántos aros tiene la bandera olímpica?", "5", "4", "6", "7"),
    qa(3, "¿Cuántas cuerdas tiene una guitarra estándar?", "6", "4", "5", "7"),
    qa(3, "¿Quién escribió Don Quijote de la Mancha?", "Miguel de Cervantes", "Lope de Vega", "Quevedo", "García Márquez"),
    qa(3, "¿Cuántos colores tiene el arcoíris tradicional?", "7", "5", "6", "8"),
    qa(3, "¿En qué deporte se juega Wimbledon?", "Tenis", "Golf", "Cricket", "Rugby"),
    qa(3, "¿Cuántos jugadores por equipo juegan a la vez en baloncesto?", "5", "6", "7", "4"),
    qa(3, "¿Qué instrumento tiene teclas blancas y negras?", "Piano", "Violín", "Flauta", "Batería")
)
