package com.playx.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

@Composable
fun MemoryGame(g: Game, n: Int, c: Ctl) {
    val dims = listOf(3 to 4, 4 to 4, 4 to 5, 5 to 6, 6 to 6)[g.a]
    val cols = dims.first
    val rows = dims.second
    val total = cols * rows
    val syms = when (g.b) {
        0 -> "ABCDEFGHIJKLMNOPQR".map { "$it" }
        1 -> (1..18).map { "$it" }
        else -> "αβγδεζηθικλμνξοπρσ".map { "$it" }
    }
    val deck = remember { syms.take(total / 2).let { it + it }.shuffled() }
    val open = remember { mutableStateListOf<Int>() }
    val done = remember { sb(total, false) }
    val scores = remember { sl(n, 0) }
    var turn by remember { mutableIntStateOf(0) }
    var moves by remember { mutableIntStateOf(0) }
    LaunchedEffect(open.size) {
        if (open.size == 2) {
            delay(700)
            if (deck[open[0]] == deck[open[1]]) {
                done[open[0]] = true; done[open[1]] = true
                scores[turn] = scores[turn] + 1
            } else turn = (turn + 1) % n
            moves++
            open.clear()
        }
    }
    if (done.all { it }) {
        val lines = if (n == 1) listOf("Lo lograste en $moves intentos.") else scores.mapIndexed { i, s -> "${pn(i)}: $s pares" }
        Result("¡Tablero completo!", lines, c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        T(if (n == 1) "Intentos: $moves" else "Turno de ${pn(turn)} · " + scores.mapIndexed { i, s -> "J${i + 1}:$s" }.joinToString("  "), 15, true, PCOL[turn % PCOL.size])
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (cc in 0 until cols) {
                    val i = r * cols + cc
                    val shown = done[i] || open.contains(i)
                    val shape = RoundedCornerShape(14.dp)
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).clip(shape)
                            .background(Brush.linearGradient(if (shown) listOf(Red.copy(alpha = 0.55f), RedDeep.copy(alpha = 0.5f)) else listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.04f))))
                            .border(1.dp, Color.White.copy(alpha = if (done[i]) 0.2f else 0.5f), shape)
                            .clickable(enabled = !shown && open.size < 2) { open.add(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (shown) T(deck[i], if (cols >= 5) 20 else 26, true, Color.White.copy(alpha = if (done[i]) 0.5f else 1f))
                    }
                }
            }
        }
    }
}

@Composable
fun LineGame(g: Game, c: Ctl) {
    val rows = g.a
    val cols = g.b
    val kk = g.c
    val grav = g.d == 1
    val cells = remember { sl(rows * cols, -1) }
    var turn by remember { mutableIntStateOf(0) }
    var win by remember { mutableIntStateOf(-2) }
    fun check(p: Int): Boolean {
        for (r in 0 until rows) for (cc in 0 until cols) for ((dr, dc) in listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)) {
            var k = 0
            while (k < kk) {
                val rr = r + dr * k
                val c2 = cc + dc * k
                if (rr !in 0 until rows || c2 !in 0 until cols || cells[rr * cols + c2] != p) break
                k++
            }
            if (k == kk) return true
        }
        return false
    }
    fun play(r: Int, cc: Int) {
        var row = r
        if (grav) row = (rows - 1 downTo 0).firstOrNull { cells[it * cols + cc] == -1 } ?: return
        else if (cells[r * cols + cc] != -1) return
        cells[row * cols + cc] = turn
        if (check(turn)) win = turn
        else if (cells.none { it == -1 }) win = -1
        else turn = 1 - turn
    }
    if (win != -2) {
        Result(if (win == -1) "Empate" else "¡Gana ${if (win == 0) "Rojo" else "Blanco"}!", listOf("Línea de $kk en tablero ${rows}x$cols"), c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        T("Turno de ${if (turn == 0) "Rojo" else "Blanco"} · forma $kk en línea", 16, true, PCOL[turn])
        Spacer(Modifier.height(6.dp))
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (cc in 0 until cols) {
                    val v = cells[r * cols + cc]
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.07f))
                            .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                            .clickable { play(r, cc) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (v >= 0) Box(Modifier.fillMaxSize(0.78f).clip(CircleShape).background(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.8f), PCOL[v], PCOL[v].copy(alpha = 0.6f)))))
                    }
                }
            }
        }
    }
}

class Q(val text: String, val opts: List<Int>, val ans: Int)

fun makeQ(op: Int, hard: Boolean): Q {
    val o = if (op == 4) Random.nextInt(4) else op
    val a: Int
    val b: Int
    val ans: Int
    val sym: String
    when (o) {
        0 -> { a = Random.nextInt(1, if (hard) 100 else 21); b = Random.nextInt(1, if (hard) 100 else 21); ans = a + b; sym = "+" }
        1 -> { a = Random.nextInt(2, if (hard) 100 else 21); b = Random.nextInt(1, a + 1); ans = a - b; sym = "−" }
        2 -> { a = Random.nextInt(2, if (hard) 16 else 11); b = Random.nextInt(2, if (hard) 14 else 11); ans = a * b; sym = "×" }
        else -> { b = Random.nextInt(2, if (hard) 13 else 10); ans = Random.nextInt(2, if (hard) 16 else 11); a = b * ans; sym = "÷" }
    }
    val set = LinkedHashSet<Int>()
    set.add(ans)
    while (set.size < 4) set.add(abs(ans + Random.nextInt(1, 11) * (if (Random.nextBoolean()) 1 else -1)))
    return Q("$a $sym $b", set.toList().shuffled(), ans)
}

@Composable
fun MathGame(g: Game, n: Int, c: Ctl) {
    val scores = remember { sl(n, 0) }
    var player by remember { mutableIntStateOf(0) }
    var phase by remember { mutableIntStateOf(0) }
    var left by remember { mutableIntStateOf(g.b) }
    var q by remember { mutableStateOf(makeQ(g.a, g.c == 1)) }
    LaunchedEffect(phase, player) {
        if (phase == 1) {
            left = g.b
            while (left > 0) { delay(1000); left-- }
            phase = 0
            player++
        }
    }
    if (player >= n) {
        val rank = scores.withIndex().sortedByDescending { it.value }.map { "${pn(it.index)}: ${it.value} aciertos" }
        Result("Resultados", rank, c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (phase == 0) {
            Glass(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Turno de ${pn(player)}", 22, true, PCOL[player % PCOL.size])
                    T("Tienes ${g.b} segundos. ¡Responde todo lo que puedas!", 15, align = TextAlign.Center)
                }
            }
            Btn("Empezar", Modifier.fillMaxWidth()) { q = makeQ(g.a, g.c == 1); phase = 1 }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T("$left s", 22, true, Red)
                T("Aciertos: ${scores[player]}", 18, true)
            }
            Glass(Modifier.fillMaxWidth()) {
                Box(Modifier.fillMaxWidth().padding(vertical = 34.dp), contentAlignment = Alignment.Center) { T(q.text, 44, true) }
            }
            q.opts.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { opt ->
                        Btn("$opt", Modifier.weight(1f), primary = false) {
                            if (opt == q.ans) scores[player] = scores[player] + 1
                            q = makeQ(g.a, g.c == 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TriviaGame(g: Game, n: Int, c: Ctl) {
    val qs = remember { (if (g.c == 4) QS else QS.filter { it.cat == g.c }).shuffled().take(g.a) }
    val scores = remember { sl(n, 0) }
    var idx by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<String?>(null) }
    if (idx >= qs.size) {
        val rank = scores.withIndex().sortedByDescending { it.value }.map { "${pn(it.index)}: ${it.value} aciertos" }
        Result("Fin de la trivia", rank, c)
        return
    }
    val q = qs[idx]
    val opts = remember(idx) { q.o.shuffled() }
    val correct = q.o[0]
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        T("Pregunta ${idx + 1} de ${qs.size} · " + pn(idx % n), 14, true, PCOL[(idx % n) % PCOL.size])
        Glass(Modifier.fillMaxWidth()) { T(q.q, 21, true, modifier = Modifier.padding(22.dp)) }
        opts.forEach { o ->
            val p = picked
            Btn(o, Modifier.fillMaxWidth(), primary = p != null && o == correct) {
                if (picked == null) {
                    picked = o
                    if (o == correct) scores[idx % n] = scores[idx % n] + 1
                }
            }
        }
        val p = picked
        if (p != null) {
            T(if (p == correct) "¡Correcto!" else "La respuesta era: $correct", 16, true, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Btn("Siguiente", Modifier.fillMaxWidth()) { picked = null; idx++ }
        }
    }
}

@Composable
fun DuelGame(g: Game, c: Ctl) {
    val sc = remember { sl(2, 0) }
    var go by remember { mutableStateOf(false) }
    var round by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf("Esperen la señal…") }
    LaunchedEffect(round) {
        go = false
        delay(Random.nextLong(1500, 4500))
        go = true
    }
    if (sc.any { it >= g.a }) {
        Result("¡Gana ${if (sc[0] >= g.a) "Jugador 1" else "Jugador 2"}!", listOf("Marcador: ${sc[0]} - ${sc[1]}"), c)
        return
    }
    fun tap(p: Int) {
        if (go) { sc[p] = sc[p] + 1; info = "Punto para ${pn(p)}"; go = false; round++ }
        else { sc[p] = (sc[p] - 1).coerceAtLeast(0); info = "${pn(p)} se adelantó (-1)"; round++ }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        for (p in 0..1) {
            val shape = RoundedCornerShape(24.dp)
            Box(
                Modifier.fillMaxWidth().height(240.dp).clip(shape)
                    .background(if (go) Brush.verticalGradient(listOf(Color(0xFFFF5A68), Color(0xFFB0001A))) else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))))
                    .border(1.dp, Color.White.copy(alpha = 0.5f), shape)
                    .clickable { tap(p) },
                contentAlignment = Alignment.Center
            ) {
                Column(Modifier.then(if (p == 0) Modifier.rotate(180f) else Modifier), horizontalAlignment = Alignment.CenterHorizontally) {
                    T(if (go) "¡YA!" else "Espera…", 40, true)
                    T("${pn(p)}: ${sc[p]} / ${g.a}", 16)
                }
            }
            if (p == 0) T(info, 14, color = Color.White.copy(alpha = 0.75f), align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun SoloReact(g: Game, c: Ctl) {
    val times = remember { mutableStateListOf<Long>() }
    var phase by remember { mutableIntStateOf(0) }
    var t0 by remember { mutableLongStateOf(0L) }
    var last by remember { mutableLongStateOf(0L) }
    LaunchedEffect(phase) {
        if (phase == 1) {
            delay(Random.nextLong(1500, 4500))
            t0 = System.nanoTime()
            phase = 2
        }
    }
    if (times.size >= g.a) {
        Result("Promedio: ${times.average().toLong()} ms", listOf("Mejor tiempo: ${times.minOrNull() ?: 0} ms", "Intentos: ${times.size}"), c)
        return
    }
    val shape = RoundedCornerShape(28.dp)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        T("Intento ${times.size + 1} de ${g.a}", 15, true)
        Box(
            Modifier.fillMaxWidth().height(360.dp).clip(shape)
                .background(if (phase == 2) Brush.verticalGradient(listOf(Color(0xFFFF5A68), Color(0xFFB0001A))) else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))))
                .border(1.dp, Color.White.copy(alpha = 0.5f), shape)
                .clickable {
                    when (phase) {
                        0, 3, 4 -> phase = 1
                        1 -> phase = 4
                        2 -> { last = (System.nanoTime() - t0) / 1_000_000L; times.add(last); phase = 3 }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            T(
                when (phase) {
                    0 -> "Toca para empezar"
                    1 -> "Espera la señal…"
                    2 -> "¡TOCA!"
                    3 -> "$last ms\nToca para seguir"
                    else -> "Muy pronto. Toca para reintentar"
                }, 26, true, align = TextAlign.Center, modifier = Modifier.padding(20.dp)
            )
        }
    }
}

@Composable
fun HiLoGame(g: Game, c: Ctl) {
    var cur by remember { mutableIntStateOf(Random.nextInt(1, g.a + 1)) }
    var lives by remember { mutableIntStateOf(g.b) }
    var streak by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(0) }
    var note by remember { mutableStateOf("¿El siguiente será mayor o menor?") }
    fun guess(higher: Boolean) {
        var nx = Random.nextInt(1, g.a + 1)
        while (nx == cur) nx = Random.nextInt(1, g.a + 1)
        if ((nx > cur) == higher) { streak++; best = max(best, streak); note = "Salió $nx. ¡Bien!" }
        else { lives--; streak = 0; note = "Salió $nx. Fallaste." }
        cur = nx
    }
    if (lives <= 0) {
        Result("Fin del juego", listOf("Mejor racha: $best"), c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("Vidas: $lives", 16, true)
            T("Racha: $streak", 16, true, Red)
        }
        Glass(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().padding(vertical = 44.dp), contentAlignment = Alignment.Center) { T("$cur", 88, true) }
        }
        T(note, 15, color = Color.White.copy(alpha = 0.8f), align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Btn("Mayor", Modifier.fillMaxWidth()) { guess(true) }
        Btn("Menor", Modifier.fillMaxWidth(), primary = false) { guess(false) }
    }
}

@Composable
fun SimonGame(g: Game, c: Ctl) {
    val seq = remember { mutableStateListOf<Int>() }
    var lit by remember { mutableIntStateOf(-1) }
    var input by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var over by remember { mutableStateOf(false) }
    val cols = listOf(Color(0xFFFF2D3F), Color(0xFFFFFFFF), Color(0xFFFF8A94), Color(0xFFB0001A), Color(0xFFFFC2C7), Color(0xFF8A8A8A))
    LaunchedEffect(seq.size) {
        input = false
        pos = 0
        if (seq.isEmpty()) {
            seq.add(Random.nextInt(g.a))
        } else {
            delay(500)
            for (i in seq.toList()) { lit = i; delay(g.b.toLong()); lit = -1; delay(150) }
            input = true
        }
    }
    fun press(i: Int) {
        if (!input || over) return
        if (seq[pos] == i) {
            pos++
            if (pos == seq.size) { input = false; seq.add(Random.nextInt(g.a)) }
        } else over = true
    }
    if (over) {
        Result("Fin del juego", listOf("Nivel alcanzado: ${seq.size - 1}"), c)
        return
    }
    val per = if (g.a == 4) 2 else 3
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T("Nivel ${seq.size} · " + (if (input) "Tu turno" else "Mira la secuencia"), 18, true, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        (0 until g.a).chunked(per).forEach { rowIdx ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowIdx.forEach { i ->
                    val shape = RoundedCornerShape(22.dp)
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).clip(shape)
                            .background(cols[i].copy(alpha = if (lit == i) 1f else 0.28f))
                            .border(1.dp, Color.White.copy(alpha = 0.5f), shape)
                            .clickable { press(i) },
                        contentAlignment = Alignment.Center
                    ) { T("${i + 1}", 28, true, if (cols[i] == Color(0xFFFFFFFF) || cols[i] == Color(0xFFFFC2C7)) Color.Black.copy(alpha = 0.6f) else Color.White) }
                }
            }
        }
    }
}

@Composable
fun GuessGame(g: Game, c: Ctl) {
    val target = remember { Random.nextInt(1, g.a + 1) }
    var text by remember { mutableStateOf("") }
    var tries by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf("Adivina un número entre 1 y ${g.a}") }
    var won by remember { mutableStateOf(false) }
    if (won) {
        Result("¡Adivinaste!", listOf("Era $target", "Intentos: $tries"), c)
        return
    }
    if (g.b > 0 && tries >= g.b) {
        Result("Sin intentos", listOf("El número era $target"), c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        T(if (g.b > 0) "Intentos: $tries de ${g.b}" else "Intentos: $tries", 15, true)
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                T(hint, 18, true, align = TextAlign.Center)
                BasicTextField(
                    value = text,
                    onValueChange = { text = it.filter { ch -> ch.isDigit() }.take(6) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = TextStyle(color = Color.White, fontSize = 36.sp, textAlign = TextAlign.Center),
                    cursorBrush = SolidColor(Red),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )
            }
        }
        Btn("Probar", Modifier.fillMaxWidth()) {
            val v = text.toIntOrNull()
            if (v == null || v < 1 || v > g.a) hint = "Escribe un número entre 1 y ${g.a}"
            else {
                tries++
                when {
                    v == target -> won = true
                    v < target -> hint = "$v es muy bajo. Prueba más alto ↑"
                    else -> hint = "$v es muy alto. Prueba más bajo ↓"
                }
                text = ""
            }
        }
    }
}
