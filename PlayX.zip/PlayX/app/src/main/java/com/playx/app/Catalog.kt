package com.playx.app

enum class Eng(val cat: String, val icon: Ic, val minP: Int, val maxP: Int, val rules: String) {
    PARTY("Fiesta", Ic.USERS, 2, 12, "Pasen el celular. En cada turno aparece una consigna para quien le toca. Cúmplela y pulsa Siguiente. Si no te gusta, pide otra consigna."),
    BASTA("Fiesta", Ic.PEN, 2, 10, "Aparece una letra y varias categorías. Todos escriben en papel palabras que empiecen con esa letra. Quien termina pulsa ¡BASTA! y luego se reparten los puntos. Son 5 rondas."),
    TORRE("Mesa", Ic.STACK, 2, 8, "Por turnos, cada jugador saca un bloque. Cuantos más bloques faltan, más riesgo hay de que caiga. Quien derrumba la torre pierde."),
    IMPERIO("Estrategia", Ic.HOME, 2, 6, "Tira el dado, compra propiedades y cobra renta a los demás. Pasar por la salida da 150. Quien se queda sin monedas queda fuera. Gana el último en pie o el más rico al terminar los turnos."),
    CARRERA("Mesa", Ic.DICE, 2, 6, "Tira el dado y avanza. Las casillas múltiplo de 7 impulsan, las de 11 hacen retroceder y las de 13 dan turno extra. Gana quien llegue primero a la meta."),
    MEMORY("Mente", Ic.DOTS, 1, 4, "Voltea dos cartas por turno. Si son iguales, las ganas y repites turno. Gana quien junte más pares."),
    LINE("Estrategia", Ic.CROSS, 2, 2, "Dos jugadores alternan fichas en el tablero. Gana quien forme primero una línea del largo indicado. En las versiones con gravedad, las fichas caen hasta el fondo."),
    MATH("Mente", Ic.PLUS, 1, 4, "Cada jugador tiene un tiempo límite para resolver tantas operaciones como pueda eligiendo la respuesta correcta. Gana quien acierte más."),
    TRIVIA("Mente", Ic.STAR, 1, 4, "Las preguntas se reparten por turnos entre los jugadores. Cada acierto suma un punto."),
    REACT("Rapidez", Ic.BOLT, 1, 2, "Espera la señal y toca lo más rápido que puedas. Tocar antes de tiempo penaliza."),
    HILO("Cartas", Ic.CARDS, 1, 1, "Adivina si el siguiente número será mayor o menor que el actual. Acumula racha y cuida tus vidas."),
    SIMON("Mente", Ic.GRID, 1, 1, "Mira la secuencia de luces y repítela tocando los botones en el mismo orden. Cada nivel agrega un paso."),
    GUESS("Mente", Ic.TARGET, 1, 1, "Hay un número secreto. Escribe tu intento y recibe pistas de más alto o más bajo.")
}

data class Game(val id: Int, val name: String, val eng: Eng, val a: Int, val b: Int, val c: Int, val d: Int, val desc: String) {
    val minP: Int get() = if (eng == Eng.REACT) (if (b == 1) 1 else 2) else eng.minP
    val maxP: Int get() = if (eng == Eng.REACT) (if (b == 1) 1 else 2) else eng.maxP
    fun players(): String = if (minP == maxP) "$minP ${if (minP == 1) "jugador" else "jugadores"}" else "$minP–$maxP jugadores"
}

val CATALOG: List<Game> by lazy { buildCatalog() }

private fun buildCatalog(): List<Game> {
    val l = ArrayList<Game>()
    fun add(n: String, e: Eng, desc: String, a: Int = 0, b: Int = 0, c: Int = 0, d: Int = 0) { l.add(Game(l.size + 1, n, e, a, b, c, d, desc)) }
    val modo = listOf("Express", "Normal", "Maratón")
    DECKS.forEachIndexed { i, deck -> listOf(8, 15, 25).forEachIndexed { k, r -> add("${deck.first} ${modo[k]}", Eng.PARTY, "$r turnos", i, r) } }
    BASTA_SETS.forEachIndexed { i, s -> listOf(30, 60, 90).forEach { t -> add("Basta ${s.first} ${t}s", Eng.BASTA, "5 rondas de $t segundos", i, t) } }
    val riesgo = listOf("suave", "normal", "extrema")
    listOf(6, 9, 12, 15, 18).forEach { h -> riesgo.forEachIndexed { r, rn -> add("Torre $h niveles $rn", Eng.TORRE, "Torre de $h niveles, caída $rn", h, r) } }
    listOf(12, 16, 20, 24).forEach { s -> listOf(500, 1000, 1500).forEach { m -> add("Imperio $s casillas $m", Eng.IMPERIO, "Tablero de $s casillas, $m monedas", s, m) } }
    listOf(20, 30, 40, 50).forEach { s -> listOf(1, 2).forEach { d -> add("Carrera $s casillas ${if (d == 1) "1 dado" else "2 dados"}", Eng.CARRERA, "Meta en la casilla $s", s, d) } }
    val mem = listOf("Letras", "Números", "Griego")
    listOf(3 to 4, 4 to 4, 4 to 5, 5 to 6, 6 to 6).forEachIndexed { i, cr -> mem.forEachIndexed { k, sn -> add("Memoria ${cr.first}x${cr.second} $sn", Eng.MEMORY, "${cr.first * cr.second / 2} pares", i, k) } }
    val lines = listOf(
        intArrayOf(3, 3, 3, 0), intArrayOf(4, 4, 3, 0), intArrayOf(4, 4, 4, 0), intArrayOf(5, 5, 4, 0),
        intArrayOf(5, 5, 5, 0), intArrayOf(6, 6, 5, 0), intArrayOf(6, 7, 4, 1), intArrayOf(5, 6, 4, 1),
        intArrayOf(7, 8, 4, 1), intArrayOf(5, 5, 3, 1), intArrayOf(7, 7, 5, 0), intArrayOf(9, 9, 5, 0)
    )
    lines.forEach { v -> add(if (v[3] == 1) "Conecta ${v[2]} ${v[0]}x${v[1]}" else "Línea de ${v[2]} ${v[0]}x${v[1]}", Eng.LINE, "Forma ${v[2]} en línea", v[0], v[1], v[2], v[3]) }
    val ops = listOf("Sumas", "Restas", "Multiplicaciones", "Divisiones", "Mixto")
    ops.forEachIndexed { o, on -> listOf(30, 60, 90).forEach { t -> listOf(0, 1).forEach { h -> add("Cálculo $on ${if (h == 0) "fácil" else "difícil"} ${t}s", Eng.MATH, "${t} segundos por jugador", o, t, h) } } }
    listOf(0, 1, 2, 3, 4).forEach { cat -> listOf(5, 8).forEach { r -> add("Trivia ${TCATS[cat]} $r", Eng.TRIVIA, "$r preguntas", r, 0, cat) } }
    listOf(5, 10, 15, 20, 25, 30).forEach { t -> add("Duelo de reflejos a $t", Eng.REACT, "El primero en $t puntos gana", t, 0) }
    listOf(3, 5, 10, 15).forEach { r -> add("Reflejos en solitario $r", Eng.REACT, "$r intentos", r, 1) }
    listOf(10, 20, 50, 100).forEach { m -> listOf(3, 1).forEach { v -> add("Mayor o menor 1-$m ${if (v == 3) "3 vidas" else "1 vida"}", Eng.HILO, "Números del 1 al $m", m, v) } }
    listOf(4, 6).forEach { nb -> listOf(700, 500, 350, 250).forEach { ms -> add("Secuencia $nb botones ${ms}ms", Eng.SIMON, "Luces de $ms ms", nb, ms) } }
    listOf(10, 50, 100, 500, 1000, 10000).forEach { r -> listOf(0, 1).forEach { lim ->
        val tries = if (lim == 0) 0 else (Math.ceil(Math.log(r.toDouble()) / Math.log(2.0)).toInt() + 2)
        add("Adivina 1-$r ${if (lim == 0) "libre" else "$tries intentos"}", Eng.GUESS, "Número del 1 al $r", r, tries)
    } }
    return l
}
