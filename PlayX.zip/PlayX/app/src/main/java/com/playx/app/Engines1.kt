package com.playx.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun PartyGame(g: Game, n: Int, c: Ctl) {
    val deck = remember { DECKS[g.a].second.shuffled() }
    var turn by remember { mutableIntStateOf(0) }
    var shift by remember { mutableIntStateOf(0) }
    if (turn >= g.b) {
        Result("¡Ronda completa!", listOf("Se jugaron ${g.b} turnos entre $n jugadores."), c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                T("Turno ${turn + 1} de ${g.b}", 13, color = Color.White.copy(alpha = 0.6f))
                T("Le toca a ${pn(turn % n)}", 20, true, PCOL[(turn % n) % PCOL.size])
                T(deck[(turn + shift) % deck.size], 22, true, align = TextAlign.Center, modifier = Modifier.padding(vertical = 18.dp))
            }
        }
        Btn("Siguiente", Modifier.fillMaxWidth()) { turn++; shift = 0 }
        Btn("Otra consigna", Modifier.fillMaxWidth(), primary = false) { shift++ }
    }
}

@Composable
fun BastaGame(g: Game, n: Int, c: Ctl) {
    val cats = BASTA_SETS[g.a].second
    val total = 5
    val scores = remember { sl(n, 0) }
    var round by remember { mutableIntStateOf(0) }
    var letter by remember { mutableStateOf(LETTERS.random()) }
    var left by remember { mutableIntStateOf(g.b) }
    var running by remember { mutableStateOf(true) }
    LaunchedEffect(round, running) {
        if (running) {
            left = g.b
            while (left > 0) { delay(1000); left-- }
            running = false
        }
    }
    if (round >= total) {
        val rank = scores.withIndex().sortedByDescending { it.value }.map { "${pn(it.index)}: ${it.value} puntos" }
        Result("Resultados finales", rank, c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                T("Ronda ${round + 1} de $total", 13, color = Color.White.copy(alpha = 0.6f))
                T("$letter", 84, true, Red)
                T(if (running) "$left s" else "¡Tiempo o BASTA!", 20, true)
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                cats.forEach { T("• $it", 17) }
            }
        }
        if (running) {
            Btn("¡BASTA!", Modifier.fillMaxWidth()) { running = false }
        } else {
            Glass(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    T("Repartan puntos", 15, true)
                    for (i in 0 until n) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            T("${pn(i)}: ${scores[i]}", 15, modifier = Modifier.weight(1f))
                            Btn("+5", primary = false) { scores[i] = scores[i] + 5 }
                            Btn("+10", primary = false) { scores[i] = scores[i] + 10 }
                        }
                    }
                }
            }
            Btn(if (round == total - 1) "Ver resultados" else "Siguiente ronda", Modifier.fillMaxWidth()) {
                round++; letter = LETTERS.random(); running = true
            }
        }
    }
}

@Composable
fun TorreGame(g: Game, n: Int, c: Ctl) {
    val h = g.a
    val risk = g.b
    val gone = remember { sb(h * 3, false) }
    var turn by remember { mutableIntStateOf(0) }
    var fell by remember { mutableIntStateOf(-1) }
    var last by remember { mutableStateOf("La torre está firme. ¡Saca un bloque!") }
    val removed = gone.count { it }
    if (fell >= 0) {
        Result("¡Se derrumbó!", listOf("${pn(fell)} tiró la torre.", "Bloques sacados: $removed"), c)
        return
    }
    if (removed >= (h - 1) * 3) {
        Result("¡Torre vacía!", listOf("Nadie la derrumbó. ¡Empate de valientes!"), c)
        return
    }
    val bh = (380f / h).coerceAtMost(34f).dp
    fun pull(i: Int) {
        val col = i % 3
        val base = 0.03f + 0.04f * risk
        val grow = (removed / (h * 3f)) * (0.35f + 0.25f * risk)
        val p = ((base + grow) * (if (col == 1) 1.5f else 0.8f)).coerceIn(0.02f, 0.9f)
        if (Random.nextFloat() < p) fell = turn % n
        else { gone[i] = true; last = "${pn(turn % n)} sacó un bloque sin problemas."; turn++ }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        T("Turno de ${pn(turn % n)}", 20, true, PCOL[(turn % n) % PCOL.size])
        T(last, 14, color = Color.White.copy(alpha = 0.7f), align = TextAlign.Center)
        val stab = 1f - removed / (h * 3f - 3f)
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.1f))) {
            Box(Modifier.fillMaxWidth(stab.coerceIn(0.02f, 1f)).fillMaxHeight().background(Brush.horizontalGradient(listOf(RedDeep, Red))))
        }
        T("Estabilidad", 11, color = Color.White.copy(alpha = 0.5f))
        Column(Modifier.fillMaxWidth(0.8f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            for (r in h - 1 downTo 0) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    for (cc in 0 until 3) {
                        val i = r * 3 + cc
                        val shape = RoundedCornerShape(6.dp)
                        if (gone[i]) {
                            Spacer(Modifier.weight(1f).height(bh))
                        } else {
                            val top = r == h - 1
                            Box(
                                Modifier.weight(1f).height(bh).clip(shape)
                                    .background(Brush.verticalGradient(if (top) listOf(Color.White.copy(alpha = 0.35f), Color.White.copy(alpha = 0.12f)) else listOf(Red.copy(alpha = 0.55f), RedDeep.copy(alpha = 0.55f))))
                                    .border(1.dp, Color.White.copy(alpha = 0.45f), shape)
                                    .then(if (top) Modifier else Modifier.clickable { pull(i) })
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ImperioGame(g: Game, n: Int, c: Ctl) {
    val size = g.a
    val pos = remember { sl(n, 0) }
    val coins = remember { sl(n, g.b) }
    val alive = remember { sb(n, true) }
    val owner = remember { sl(size, -1) }
    var turn by remember { mutableIntStateOf(0) }
    var pending by remember { mutableIntStateOf(-1) }
    var steps by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("Tira el dado para empezar.") }
    fun kind(i: Int) = when { i == 0 -> 0; i % 5 == 3 -> 1; i % 7 == 5 -> 2; else -> 3 }
    fun price(i: Int) = (40 + 12 * i) / 10 * 10
    fun advance() { steps++; var t = (turn + 1) % n; while (!alive[t]) t = (t + 1) % n; turn = t }
    fun roll() {
        val p = turn
        val d = Random.nextInt(1, 7)
        val old = pos[p]
        val np = (old + d) % size
        var m = "${pn(p)} sacó $d. "
        if (old + d >= size) { coins[p] = coins[p] + 150; m += "Pasó por la salida (+150). " }
        pos[p] = np
        var wait = false
        when (kind(np)) {
            0 -> m += "Casilla de salida."
            1 -> {
                val v = listOf(-80, -40, 60, 100, 120).random()
                coins[p] = coins[p] + v
                m += "Suerte: " + (if (v > 0) "+$v" else "$v") + "."
            }
            2 -> { coins[p] = coins[p] - 60; m += "Impuesto: -60." }
            else -> {
                val o = owner[np]
                if (o == -1) {
                    if (coins[p] >= price(np)) { pending = np; wait = true; m += "Casilla ${np + 1} en venta por ${price(np)}." }
                    else m += "No alcanza para comprar."
                } else if (o == p) {
                    m += "Es tu propiedad."
                } else {
                    val rent = price(np) / 4
                    coins[p] = coins[p] - rent
                    coins[o] = coins[o] + rent
                    m += "Paga renta de $rent a ${pn(o)}."
                }
            }
        }
        if (coins[p] < 0) {
            alive[p] = false
            for (i in 0 until size) if (owner[i] == p) owner[i] = -1
            m += " ¡${pn(p)} quebró!"
            wait = false
            pending = -1
        }
        msg = m
        if (!wait) advance()
    }
    fun decide(buy: Boolean) {
        val p = turn
        if (buy) {
            coins[p] = coins[p] - price(pending)
            owner[pending] = p
            msg = "${pn(p)} compró la casilla ${pending + 1}."
        } else msg = "${pn(p)} decidió no comprar."
        pending = -1
        advance()
    }
    if (alive.count { it } <= 1 || steps >= n * 18) {
        val worth = List(n) { p -> if (!alive[p]) -1 else coins[p] + (0 until size).filter { owner[it] == p }.sumOf { price(it) } }
        val w = worth.indices.maxByOrNull { worth[it] } ?: 0
        Result("¡Gana ${pn(w)}!", worth.mapIndexed { i, v -> "${pn(i)}: " + (if (v < 0) "quebró" else "patrimonio $v") }, c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                T("Turno de ${pn(turn)} · ${coins[turn]} monedas", 17, true, PCOL[turn % PCOL.size])
                T(msg, 14, color = Color.White.copy(alpha = 0.8f))
            }
        }
        (0 until size).chunked(4).forEach { rowIdx ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rowIdx.forEach { i -> Tile(i, kind(i), price(i), owner[i], pos.indices.filter { alive[it] && pos[it] == i }) }
                repeat(4 - rowIdx.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 0 until n) T("${pn(i)}: " + (if (alive[i]) "${coins[i]} monedas" else "fuera"), 13, color = PCOL[i % PCOL.size])
            }
        }
        if (pending >= 0) {
            Btn("Comprar por ${price(pending)}", Modifier.fillMaxWidth()) { decide(true) }
            Btn("Pasar", Modifier.fillMaxWidth(), primary = false) { decide(false) }
        } else {
            Btn("Tirar dado", Modifier.fillMaxWidth()) { roll() }
        }
    }
}

@Composable
fun RowScope.Tile(i: Int, kind: Int, price: Int, owner: Int, here: List<Int>) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.weight(1f).height(74.dp).clip(shape)
            .background(if (owner >= 0) PCOL[owner % PCOL.size].copy(alpha = 0.28f) else Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.25f), shape).padding(5.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        T("${i + 1}", 10, color = Color.White.copy(alpha = 0.6f))
        T(when (kind) { 0 -> "SAL"; 1 -> "?"; 2 -> "IMP"; else -> "$price" }, 13, true)
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            here.forEach { Box(Modifier.size(9.dp).background(PCOL[it % PCOL.size], CircleShape)) }
        }
    }
}

@Composable
fun CarreraGame(g: Game, n: Int, c: Ctl) {
    val len = g.a
    val pos = remember { sl(n, 0) }
    var turn by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("Tira el dado.") }
    var win by remember { mutableIntStateOf(-1) }
    fun roll() {
        val p = turn
        var d = 0
        repeat(g.b) { d += Random.nextInt(1, 7) }
        var np = pos[p] + d
        var m = "${pn(p)} sacó $d."
        if (np >= len) { pos[p] = len; win = p; return }
        if (np % 7 == 0) { np += 3; m += " ¡Impulso +3!" }
        else if (np % 11 == 0) { np = (np - 3).coerceAtLeast(0); m += " Retrocede 3." }
        pos[p] = np.coerceAtMost(len)
        if (np >= len) { win = p; return }
        if (np % 13 == 0 && np > 0) m += " ¡Turno extra!" else turn = (turn + 1) % n
        msg = m
    }
    if (win >= 0) {
        Result("¡Gana ${pn(win)}!", pos.mapIndexed { i, p -> "${pn(i)}: casilla $p de $len" }, c)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                T("Turno de ${pn(turn)}", 18, true, PCOL[turn % PCOL.size])
                T(msg, 14, color = Color.White.copy(alpha = 0.8f))
            }
        }
        for (i in 0 until n) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                T("${pn(i)} · ${pos[i]}/$len", 13, color = PCOL[i % PCOL.size])
                Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.1f))) {
                    Box(Modifier.fillMaxWidth((pos[i] / len.toFloat()).coerceIn(0.03f, 1f)).fillMaxHeight().background(PCOL[i % PCOL.size].copy(alpha = 0.85f)))
                }
            }
        }
        Btn("Tirar ${if (g.b == 1) "dado" else "dados"}", Modifier.fillMaxWidth()) { roll() }
    }
}
